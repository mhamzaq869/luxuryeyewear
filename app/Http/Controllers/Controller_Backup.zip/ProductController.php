<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use App\Models\Brand;
use App\Models\Attribute;
use App\Models\ProductColor;
use App\Models\PrescriptionData;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ImportProduct;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    /**

     * Display a listing of the resource.

     *

     * @return \Illuminate\Http\Response

     */

    public function index()
    {
        $data['products']=Product::getAllProduct(); 
        // return $products;
        return view('backend.product.index', $data);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['brands']=Brand::get();
        $data['categories']=Category::where('is_parent',1)->get();
        $data['types']=Attribute::where('attribute_type', 'type')->get();
        $data['lensTypes']=Attribute::where('attribute_type', 'lens_type')->get();
        $data['shapes']=Attribute::where('attribute_type', 'shape')->get();
        $data['materials']=Attribute::where('attribute_type', 'material')->get();
        $data['product_for']=Attribute::where('attribute_type', 'product_for')->get();
        $data['frame_types']=Attribute::where('attribute_type', 'frame_type')->get();
        $data['product_colors']=ProductColor::get();
        
        $data['extras']=Attribute::where('attribute_type', 'extra')->get();
        $data['leftSpheres'] = PrescriptionData::where('sph_left','!=','')->get();
        $data['leftcylinders'] = PrescriptionData::where('cyl_left','!=','')->get();
        // return $category;

        return view('backend.product.create',$data);

    }



    /**

     * Store a newly created resource in storage.

     *

     * @param  \Illuminate\Http\Request  $request

     * @return \Illuminate\Http\Response

     */

    public function store(Request $request)
    {

        // dd($request->all());
        $this->validate($request,[
            'title'=>'string|required',
            'short_description'=>'string|required',
            'description'=>'string|nullable',
            'category_for'=>'nullable',
            'stock'=>"required|numeric",
            'cat_id'=>'required|exists:categories,id',
            'brand_id'=>'nullable|exists:brands,id',
            'child_cat_id'=>'nullable|exists:categories,id',
            'is_featured'=>'sometimes|in:1',
            'status'=>'required|in:active,inactive',
            'condition'=>'required|in:default,new,hot',
            'price'=>'required|numeric',
            'discount'=>'nullable|numeric',
            'extra' => 'required',
            'product_color' => 'required',
            'min_sph'   => 'required',
            'max_sph'   =>  'required',
            'min_cyl'   => 'required',
            'max_cyl'   => 'required',
            'product_bridge'  => 'required',
            'product_arm_length'  => 'required',
            'product_lens_height'  => 'required',
            'product_lens_width'  => 'required',
            'product_total_width'  => 'required',

        ]);


        $data=$request->all();
        $slug=Str::slug($request->title);
        $count=Product::where('slug',$slug)->count();
        if($count>0){
            $slug=$slug.'-'.date('ymdis').'-'.rand(0,999);
        }
        $data['slug']=$slug;
        $data['photo']=$request->p_f;
        $data['g_image'] = json_encode($request->g_image);
        $data['is_featured']=$request->input('is_featured',0);
        // $size=$request->input('category_for');
        // if($size){
        //     $data['category_for']=implode(',',$size);
        // }
        // else{
        //     $data['category_for']='';
        // }
    // echo"<pre>"; print_r($data); die;
    unset($data['files']);
        $status=Product::create($data);
        if($status){
            request()->session()->flash('success','Product Successfully added');
        }
        else{
            request()->session()->flash('error','Please try again!!');
        }
        return redirect()->route('product.index');
    }



    /**

     * Display the specified resource.

     *

     * @param  int  $id

     * @return \Illuminate\Http\Response

     */

    public function show($id)

    {

        //

    }



    /**

     * Show the form for editing the specified resource.

     *

     * @param  int  $id

     * @return \Illuminate\Http\Response

     */

    public function edit($id)

    {

        $brand=Brand::get();

        $product=Product::findOrFail($id);

        $category=Category::where('is_parent',1)->get();

        $items=Product::where('id',$id)->get();


        $edit_data['types']=Attribute::where('attribute_type', 'type')->get();
        $edit_data['lensTypes']=Attribute::where('attribute_type', 'lens_type')->get();
        $edit_data['shapes']=Attribute::where('attribute_type', 'shape')->get();
        $edit_data['materials']=Attribute::where('attribute_type', 'material')->get();
        $edit_data['product_for']=Attribute::where('attribute_type', 'product_for')->get();
        $edit_data['product_colors']=ProductColor::get();
        $edit_data['extras']=Attribute::where('attribute_type', 'extra')->get();
        $edit_data['leftSpheres'] = PrescriptionData::where('sph_left','!=','')->get();
        $edit_data['leftcylinders'] = PrescriptionData::where('cyl_left','!=','')->get();
        $edit_data['rightcylinders'] = PrescriptionData::where('cyl_right','!=','')->get();

        // return $items;

        return view('backend.product.edit',$edit_data)->with('product',$product)

                    ->with('brands',$brand)

                    ->with('categories',$category)->with('items',$items);

    }



    /**

     * Update the specified resource in storage.

     *

     * @param  \Illuminate\Http\Request  $request

     * @param  int  $id

     * @return \Illuminate\Http\Response

     */

    public function update(Request $request, $id)

    {
// dd($request->all());

        $product=Product::findOrFail($id);

        $this->validate($request,[

            'title'=>'string|required',

            // 'short_description'=>'string|required',

            // 'description'=>'string|nullable',

            // 'photo'=>'string|required',

            // 'size'=>'nullable',

            // 'stock'=>"required|numeric",

            // 'cat_id'=>'required|exists:categories,id',

            // 'child_cat_id'=>'nullable|exists:categories,id',

            // 'is_featured'=>'sometimes|in:1',

            // 'brand_id'=>'nullable|exists:brands,id',

            // 'status'=>'required|in:active,inactive',

            // 'condition'=>'required|in:default,new,hot',

            // 'price'=>'required|numeric',

            // 'discount'=>'nullable|numeric'

        ]);



        $data=$request->all();

        $data['is_featured']=$request->input('is_featured',0);

        // $size=$request->input('size');

        // if($size){

        //     $data['size']=implode(',',$size);

        // }

        // else{

        //     $data['size']='';

        // }

        // return $data;
        unset($data['files']);
          $data['photo']=$request->p_f;
        $status=$product->fill($data)->save();

        if($status){

            request()->session()->flash('success','Product Successfully updated');

        }

        else{

            request()->session()->flash('error','Please try again!!');

        }

        return redirect()->route('product.index');

    }



    /**

     * Remove the specified resource from storage.

     *

     * @param  int  $id

     * @return \Illuminate\Http\Response

     */

    public function destroy($id)

    {

        $product=Product::findOrFail($id);

        $status=$product->delete();

        

        if($status){

            request()->session()->flash('success','Product successfully deleted');

        }

        else{

            request()->session()->flash('error','Error while deleting product');

        }

        return redirect()->route('product.index');

    }

      /**

     * Show the form for import product.

     *

     * @return \Illuminate\Http\Response

     */

    public function getProductImport()

    {

       return view('backend.product.import');

    }

      /**

     * Store import product.

     *

     * @return \Illuminate\Http\Response

     */

    public function saveProductImport(Request $request)
    {

        Excel::import(new ImportProduct, $request->file('file')->store('files'));

        request()->session()->flash('success','Product Import Successfully!');

        return redirect()->route('product.index');

    }

}

